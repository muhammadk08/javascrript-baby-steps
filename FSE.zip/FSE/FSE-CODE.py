import pygame
from pygame import mixer
from random import randint

# Initialize Pygame
pygame.init()
mixer.init()

# Screen setup
SCREEN_WIDTH, SCREEN_HEIGHT = 1150, 850
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Space Invaders")

# Load assets
background = pygame.image.load("background.png")
background = pygame.transform.scale(background, (SCREEN_WIDTH, SCREEN_HEIGHT))
space_ship = pygame.image.load("space_ship.png")
space_ship = pygame.transform.scale(space_ship, (102, 108))
bullet = pygame.image.load("bullet.png")
bullet = pygame.transform.scale(bullet, (5, 20))
shield_img = pygame.image.load("shield.png")
shield_img = pygame.transform.scale(shield_img, (128, 96))
enemy_img = pygame.image.load("enemy.png")
enemy_img = pygame.transform.scale(enemy_img, (55, 38))
enemy_bullet_img = pygame.image.load("enemy_bullet.png")
enemy_bullet_img = pygame.transform.scale(enemy_bullet_img, (29, 34))

# Sounds
mixer.music.load("song.mp3")
mixer.music.play(-1)
shot_sound = mixer.Sound("shot.mp3")

# Player setup
player_width, player_height = 102, 108
player_x, player_y = (SCREEN_WIDTH // 2) - (player_width // 2), SCREEN_HEIGHT - 150
player_speed = 9
player_lives = 3

# Game variables
score = 0
cooldown = 0
enemy_shots = []
player_shots = []
enemies = []
enemy_direction = 1
enemy_speed = 6
enemy_drop = 20
enemy_shoot_rate = 200  # Initial shoot rate (lower = more frequent)
shield_positions = [(127, 570), (127 * 3, 570), (127 * 5, 570), (127 * 7, 570)]
shields = [shield_img.copy() for _ in shield_positions]
shield_health = [10, 10, 10, 10]  # Add health for each shield

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)

# Font
font = pygame.font.SysFont("Arial", 36)

# Functions
def reset_level():
    """Reset enemies and shields for a new level."""
    global enemies, enemy_shoot_rate, shield_health
    enemies.clear()
    shield_health[:] = [10, 10, 10, 10]  # Reset shield health
    enemy_shoot_rate = max(50, enemy_shoot_rate - 20)  # Gradually increase shooting rate
    for x in range(150, 851, 70):
        for y in [150, 200, 250, 300]:
            enemies.append(pygame.Rect(x, y, 55, 38))

def draw_text(surface, text, pos, color=WHITE):
    """Render text on the screen."""
    text_surface = font.render(text, True, color)
    surface.blit(text_surface, pos)

def move_enemies():
    """Move enemies horizontally and drop them when they hit the edges."""
    global enemy_direction
    hit_edge = False
    for enemy in enemies:
        enemy.x += enemy_direction * enemy_speed
        if enemy.right >= SCREEN_WIDTH or enemy.left <= 0:
            hit_edge = True
    if hit_edge:
        enemy_direction *= -1
        for enemy in enemies:
            enemy.y += enemy_drop

def shoot_enemy_bullets():
    """Randomly generate enemy bullets based on current shoot rate."""
    for enemy in enemies:
        if randint(1, enemy_shoot_rate) == 1:
            enemy_shots.append([enemy.centerx, enemy.bottom])

def move_bullets():
    """Move player and enemy bullets."""
    for shot in player_shots[:]:
        shot[1] -= 20  # Faster player bullets
        if shot[1] < 0:
            player_shots.remove(shot)
    for shot in enemy_shots[:]:
        shot[1] += 10  # Faster enemy bullets
        if shot[1] > SCREEN_HEIGHT:
            enemy_shots.remove(shot)

def detect_collision(rect, shots):
    """Check for collisions between a rectangle and bullets."""
    for shot in shots:
        if rect.collidepoint(shot):
            shots.remove(shot)
            return True
    return False

def player_hit():
    """Handle player getting hit by an enemy bullet."""
    global player_lives, running
    player_lives -= 1
    if player_lives <= 0:
        running = False

def weaken_shield(shield_index, shots):
    """Reduce shield size and health upon collision with a bullet."""
    if shields[shield_index] is None: 
        return

    shield_rect = shields[shield_index].get_rect(topleft=shield_positions[shield_index])
    for shot in shots[:]:
        if shield_rect.collidepoint(shot):
            shots.remove(shot)
            shield_health[shield_index] -= 1
            width, height = shields[shield_index].get_size()
            shields[shield_index].fill((0, 0, 0), pygame.Rect(randint(0, width - 20), randint(0, height - 20), 20, 20))

            # Remove the shield if health reaches 0
            if shield_health[shield_index] <= 0:
                shields[shield_index] = None

def draw_elements():
    """Draw all game elements."""
    screen.blit(background, (0, 0))
    screen.blit(space_ship, (player_x, player_y))
    for enemy in enemies:
        screen.blit(enemy_img, enemy.topleft)
    for shot in player_shots:
        screen.blit(bullet, shot)
    for shot in enemy_shots:
        screen.blit(enemy_bullet_img, shot)
    for i, pos in enumerate(shield_positions):
        if shields[i]:  # Draw shield only if it exists
            screen.blit(shields[i], pos)
    draw_text(screen, f"Lives: {player_lives}", (SCREEN_WIDTH - 150, 10), RED)

# Game loop
running = True
reset_level()
while running:
    screen.fill((0, 0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and player_x > 0:
        player_x -= player_speed
    if keys[pygame.K_RIGHT] and player_x < SCREEN_WIDTH - player_width:
        player_x += player_speed
    if keys[pygame.K_SPACE] and cooldown == 0:
        player_shots.append([player_x + player_width // 2, player_y])
        shot_sound.play()
        cooldown = 20

    move_enemies()
    move_bullets()
    shoot_enemy_bullets()

    for enemy in enemies[:]:
        if detect_collision(enemy, player_shots):
            enemies.remove(enemy)
            score += 10

    for shot in enemy_shots[:]:
        if pygame.Rect(player_x, player_y, player_width, player_height).collidepoint(shot):
            enemy_shots.remove(shot)
            player_hit()

    for i in range(len(shields)):
        if shields[i]:  
            weaken_shield(i, enemy_shots)
            weaken_shield(i, player_shots)

    if len(enemies) == 0:
        reset_level()

    cooldown = max(0, cooldown - 1)
    draw_elements()
    draw_text(screen, f"Score: {score}", (10, 10))
    pygame.display.flip()
    pygame.time.delay(30)

pygame.quit()
